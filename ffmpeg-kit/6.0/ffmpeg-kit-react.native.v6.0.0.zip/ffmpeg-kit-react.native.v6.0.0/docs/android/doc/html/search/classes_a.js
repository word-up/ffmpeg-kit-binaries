var searchData=
[
  ['lastframeduration_0',['LastFrameDuration',['../dc/d16/struct_last_frame_duration.html',1,'']]],
  ['logbuffer_1',['LogBuffer',['../dd/d15/struct_log_buffer.html',1,'']]]
];
