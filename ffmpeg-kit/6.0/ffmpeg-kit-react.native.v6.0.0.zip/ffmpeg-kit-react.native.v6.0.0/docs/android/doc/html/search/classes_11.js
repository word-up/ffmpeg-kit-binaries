var searchData=
[
  ['writer_0',['Writer',['../d6/dff/struct_writer.html',1,'']]],
  ['writercontext_1',['WriterContext',['../d1/da2/struct_writer_context.html',1,'']]]
];
